package com.example.fileexplorer;

import javafx.beans.property.SimpleStringProperty;
import javafx.scene.image.ImageView;

import java.io.File;

public class FileInfo {
    private ImageView image;
    private SimpleStringProperty name;
    private SimpleStringProperty size;
    private File file;

    public FileInfo(ImageView image, String name, String size, File file) {
        super();
        this.image = image;
        this.name = new SimpleStringProperty(name);
        this.size = new SimpleStringProperty(size);
        this.file = file;
    }
    public FileInfo(String name, String size) {
        super();
        this.name = new SimpleStringProperty(name);
        this.size = new SimpleStringProperty(size);
    }

    public ImageView getImage() {
        return image;
    }

    public String getName() {
        return name.get();
    }
    public String getSize() {
        return size.get();
    }
    public File getFile() {
        return file;
    }

    public void setImage(ImageView value) {
        this.image = value;
    }

    public void setName(String newName) {

        this.name  =new SimpleStringProperty(newName);
    }
}
