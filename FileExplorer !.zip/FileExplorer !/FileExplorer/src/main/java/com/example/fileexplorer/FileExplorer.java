package com.example.fileexplorer;

import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.File;
public interface FileExplorer {

    Image getIconImageFX(File f);//it obtains the image from the given file
    TreeItem<String>[] TreeCreate(File dir);// creating links between folders
    String calculateSize(File f);//it will calculate the file size which is entered
    String FindAbsolutePath(TreeItem<String> item, String s);// it will find the actual path of the file
    boolean IsDrive(File f);
    int FilesHiddensCount(File dir);// files which are hidden in the directory
    void CreateTreeView(TreeView<String> treeview);//it will show the relation between directories
    void CreateTableView(TableView<FileInfo> tableview, TableColumn<FileInfo, ImageView> image, TableColumn<FileInfo, String> date,
                         TableColumn<FileInfo, String> name, TableColumn<FileInfo, String> size);
    void CreateTableView();
    void CreateTilesView();
    void setLabelTxt();
    void Initiate();
    void setValues(TableView<FileInfo> tableview,TableColumn<FileInfo, ImageView> image,
                   TableColumn<FileInfo, String> name,TableColumn<FileInfo, String> size);
    void CreateTiles();
    public int NumOfDirectChilds(File f);

}