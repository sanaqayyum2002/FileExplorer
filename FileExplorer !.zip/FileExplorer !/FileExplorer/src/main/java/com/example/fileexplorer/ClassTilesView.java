package com.example.fileexplorer;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.transform.Scale;

import java.io.File;
import java.io.IOException;

import static com.example.fileexplorer.FileExplorerFx.*;
import java.awt.Desktop;

public class ClassTilesView extends FileExplorerFx {
    public ClassTilesView() {
        CurrDirName = "";
    }

    @Override
    public String FindAbsolutePath(TreeItem<String> item, String s) {
        return null;
    }

    @Override
    public void CreateTreeView(TreeView<String> treeview) {
    }

    @Override
    public void CreateTableView(javafx.scene.control.TableView<FileInfo> tableview, TableColumn<FileInfo, ImageView> image, TableColumn<FileInfo, String> date, TableColumn<FileInfo, String> name, TableColumn<FileInfo, String> size) {
    }

    @Override
    public void CreateTableView() {
    }

    @Override
    public void CreateTilesView() {
    }

    @Override
    public void Initiate() {
    }

    @Override
    public void setValues(javafx.scene.control.TableView<FileInfo> tableview, TableColumn<FileInfo, ImageView> image, TableColumn<FileInfo, String> name, TableColumn<FileInfo, String> size) {
    }

    @Override
    public TreeItem<String>[] TreeCreate(File dir) {
        return null;

    }

    public void CreateTiles() {
        File[] f1;
        if (CurrDirFile == null) {
            CurrDirFile = new File("./");
        }
        f1 = CurrDirFile.listFiles();

        if (CurrDirName.equals("Thia PC")) {
            f1 = File.listRoots();
        }
        int len = f1.length;
        tilePane.getChildren().clear();
        Scale normalScale = new Scale(1.0, 1.0);
        Scale enlargeScale = new Scale(1.2, 1.2);
        DropShadow shadow = new DropShadow();
        shadow.setColor(Color.HOTPINK);
        for (int i = 0; i < len; i++) {
            Label title = new Label(f1[i].getName());
            title.setId(f1[i].getName());
            ImageView imageview = new ImageView(getIconImageFX(f1[i]));
            VBox vbox = new VBox();
            vbox.setId(f1[i].getName());
            vbox.getChildren().addAll(imageview, title);
            // Set initial scale
            vbox.getTransforms().add(normalScale);
            // Add enlargement effect on hover
            vbox.setOnMouseEntered(e -> vbox.getTransforms().setAll(enlargeScale));
            vbox.setOnMouseExited(e -> vbox.getTransforms().setAll(normalScale));

            vbox.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    if (mouseEvent.getClickCount() == 2) {
                        System.out.println("Tile pressed " + vbox.getId());
                        String str = vbox.getId();
                        String str1 = CurrDirStr + "\\" + str;
                        File f = new File(str1);
                        if (f.isFile()) {
                            Desktop d = Desktop.getDesktop();
                            try {
                                d.open(f);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        } else {
                            CurrDirStr = str1;
                            CurrDirFile = new File(CurrDirStr);
                            setLabelTxt();
                            tilePane.getChildren().clear();
                            CreateTiles();
                        }
                    }
                }
            });
            tilePane.setAlignment(vbox, Pos.BOTTOM_LEFT);
            tilePane.getChildren().add(vbox);
        }
    }
}



