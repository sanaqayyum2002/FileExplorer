package com.example.fileexplorer;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

public class ControllerTableView implements Initializable
{
@FXML
 TableView<FileInfo> tableview;
@FXML
TableColumn<FileInfo, ImageView> image;
   @FXML
   TableColumn<FileInfo,String> name;
   @FXML
   TableColumn<FileInfo,String> size;
    Desktop desktop;
   public ObservableList<FileInfo> list;
public static FileExplorerFx Fx2;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Fx2=new ClassTableView();
        Fx2.setValues(tableview,image,name,size);
        if (Fx2.CurrDirFile==null){
            Fx2.CurrDirFile=new File("./");
            Fx2.CurrDirStr=Fx2.CurrDirFile.getAbsolutePath();
        }
        {
        File[] f1;
        ObservableList<FileInfo> list;
        if (Fx2.CurrDirFile==null){
            Fx2.CurrDirFile=new File("./");
        }
        {
            f1=Fx2.CurrDirFile.listFiles();
        }
            FileInfo st[] = new FileInfo[0];
            if(f1!=null) {
                 st = new FileInfo[f1.length];
                for (int i = 0; i < f1.length; i++) {
                    String s1 = null;
                    String s2 = null;
                    String s3 = null;
                    ImageView img = null;
                    try {
                        if (Fx2.IsDrive(f1[i])) {
                            img = new ImageView(Fx2.getIconImageFX(f1[i]));
                            s1 = f1[i].getAbsolutePath();
                        } else {
                            img = new ImageView(Fx2.getIconImageFX(f1[i]));
                            s1 = f1[i].getName();
                            s2 = Fx2.calculateSize(f1[i]);
                        }
                    } catch (Exception x) {
                        System.out.println("Exception in table view string: " + x.getMessage());
                    }
                    st[i] = new FileInfo(img, s1, s2,f1[i]);
                }
            }
        list= FXCollections.observableArrayList(st);
            // Set background color for the header row
// Set background color for even and odd rows in the table body
            tableview.setRowFactory(tv -> new TableRow<FileInfo>() {
                @Override
                protected void updateItem(FileInfo item, boolean empty) {
                    super.updateItem(item, empty);
                    if (getIndex() % 2 == 0) {
                        // Even row index, set background color to light gray
                        setStyle("-fx-background-color: #FFDAE9;");
                    } else {
                        // Odd row index, set background color to white
                        setStyle("-fx-background-color: white;");
                    }
                    // Hover effect
                    setOnMouseEntered(event -> {
                        if (!isEmpty()) {
                            setStyle("-fx-background-color: #FFC0CB;"); // Change background color on hover
                        }
                    });
                    setOnMouseExited(event -> {
                        if (!isEmpty()) {
                            if (getIndex() % 2 == 0) {
                                setStyle("-fx-background-color: #FFDAE9;"); // Restore original color on exit for even rows
                            } else {
                                setStyle("-fx-background-color: white;"); // Restore original color on exit for odd rows
                            }
                        }
                    });
                }
            });
            tableview.setItems(list);
    }
    }
    @FXML
    void handleTableMouseClicked(MouseEvent mouseEvent) {
        if (mouseEvent.getClickCount() == 2) {
            FileInfo selectedItem = tableview.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                String str = selectedItem.getName();
                String s = Fx2.CurrDirStr + "\\" + str;
                System.out.println(s);
                File file = new File(s);
                if (file.isDirectory()) {
                    try {
                        Fx2.CurrDirFile = file;
                        Fx2.CurrDirStr = Fx2.CurrDirFile.getAbsolutePath();
                        Fx2.setLabelTxt();
                        tableview.getItems().clear();
                        Fx2.CreateTableView();
                    } catch (Exception x) {
                        System.out.println(x.getMessage());
                    }
                } else if (file.isFile()) {
                    desktop = Desktop.getDesktop();
                    try {
                        desktop.open(file);
                    } catch (IOException x) {
                        System.out.println(x.getMessage());
                    }
                }
            }
        }
    }


}
