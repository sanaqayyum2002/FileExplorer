package com.example.fileexplorer;

import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.TilePane;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileSystemView;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.IntBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;

public abstract class FileExplorerFx  implements FileExplorer{
static File CurrDirFile;//file object of current directory(to access the data from the file)
static String CurrDirStr;//use to refer current directory path
static Label lb1;//displaying info about the curr dir like size
static String CurrDirName;//name of the directory
    static TilePane tilePane;
    TableView<com.example.fileexplorer.FileInfo> TableView;
    TableColumn<com.example.fileexplorer.FileInfo,ImageView> image;
    TableColumn<com.example.fileexplorer.FileInfo,String> name;
    TableColumn<com.example.fileexplorer.FileInfo,String> size;
    FileExplorerFx(){
    }
    @Override
    public Image getIconImageFX(File f) {//takes a file as an input and returns image representing the icon of the file
        ImageIcon icon = (ImageIcon) FileSystemView.getFileSystemView().getSystemIcon(f);
        java.awt.Image awtImage = icon.getImage();

        // Convert awtImage to BufferedImage
        BufferedImage bufferedImage = new BufferedImage(
                awtImage.getWidth(null),
                awtImage.getHeight(null),
                BufferedImage.TYPE_INT_ARGB
        );
        bufferedImage.getGraphics().drawImage(awtImage, 0, 0, null);

        // Convert BufferedImage to JavaFX Image
        try {
            // Convert BufferedImage to byte array
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            ImageIO.write(bufferedImage, "png", byteArrayOutputStream);
            // Convert byte array to JavaFX Image
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            Image fxImage = new Image(byteArrayInputStream);
            return fxImage;
        } catch (IOException e) {
            e.printStackTrace();
        }

return null;
    }

    @Override
    public TreeItem<String>[] TreeCreate(File dir) {
        return new TreeItem[0];
    }
    @Override
    public String calculateSize(File f) {
        String s;
        long sizeInByte = 0;
        Path p;

        if (IsDrive(f)) {
            return String.format("%.2f GB", (double) f.getTotalSpace() / (1024 * 1024 * 1024));
        }

        p = f.toPath();
        try {
            sizeInByte = Files.size(p);
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (sizeInByte < 1024) {
            s = Long.toString(sizeInByte) + " B";
        } else if (sizeInByte < 1024 * 1024) {
            s = String.format("%.2f KB", (double) sizeInByte / 1024);
        } else if (sizeInByte < 1024 * 1024 * 1024) {
            s = String.format("%.2f MB", (double) sizeInByte / (1024 * 1024));
        } else {
            s = String.format("%.2f GB", (double) sizeInByte / (1024 * 1024 * 1024));
        }

        return s;
    }

    @Override
    public String FindAbsolutePath(TreeItem<String> item, String s) {

        return null;
    }
    @Override
    public boolean IsDrive(File f) {
        File[] sysroots=File.listRoots();//this will store the file names of the drive such as local disk c etc if the entered file matches any file present in this array that means that file is a drive
        for(int i=0;i< sysroots.length;i++){
            if(f.equals(sysroots[i])) {
                return true;
            }
        }
        return false;
    }
/*

    public String calculateSize(File f) {
        if (IsDrive(f)) {
            return String.format("%.2f GB", (double) f.getTotalSpace() / (1024 * 1024 * 1024));
        }

        if (f.isDirectory()) {
            long totalSize = calculateDirectorySize(f);
            return formatSize(totalSize);
        } else {
            return formatSize(f.length());
        }
    }

    private long calculateDirectorySize(File directory) {
        long size = 0;
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    size += calculateDirectorySize(file);
                } else {
                    size += file.length();
                }
            }
        }
        return size;
    }
*/

    private String formatSize(long sizeInByte) {
String s;
        if (sizeInByte < 1024) {
            s = Long.toString(sizeInByte) + " B";
        } else if (sizeInByte < 1024 * 1024) {
            s = String.format("%.2f KB", (double) sizeInByte / 1024);
        } else if (sizeInByte < 1024 * 1024 * 1024) {
            s = String.format("%.2f MB", (double) sizeInByte / (1024 * 1024));
        } else {
            s = String.format("%.2f GB", (double) sizeInByte / (1024 * 1024 * 1024));
        }

        return s;
    }


    @Override
    public int FilesHiddensCount(File dir) {
        int count=0;
        File[]F1=dir.listFiles();
        for(int i=0;i<F1.length;i++){
            try{
                if (F1[i].isHidden() || F1[i].isFile()) {
                    count++;
                }
                }
                catch(Exception x){
                    System.out.println("Exception at prototype 1, FileExplorer count directory :"+x.getMessage());

                }
            }
        return count;
    }
    @Override
    public void CreateTreeView(TreeView<String> treeview) {
    }
    @Override
    public void CreateTableView(TableView<FileInfo> tableview, TableColumn<FileInfo, ImageView> image, TableColumn<FileInfo, String> date, TableColumn<FileInfo, String> name, TableColumn<FileInfo, String> size) {
    }
    @Override
    public void CreateTableView() {
    }
    @Override
    public void CreateTilesView() {
    }
    @Override
    public void setLabelTxt() {
        lb1.setText(CurrDirStr);
    }
    @Override
    public void Initiate() {
    }
    @Override
    public void setValues(TableView<FileInfo> tableview, TableColumn<FileInfo, ImageView> image, TableColumn<FileInfo, String> name, TableColumn<FileInfo, String> size) {
    }
    @Override
    public void CreateTiles() {
    }
    @Override
    public int NumOfDirectChilds(File f) {

        return f.listFiles().length;
    }
}
