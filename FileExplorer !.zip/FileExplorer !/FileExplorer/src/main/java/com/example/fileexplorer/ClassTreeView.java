package com.example.fileexplorer;

import javafx.scene.control.TableRow;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.File;

public class ClassTreeView extends FileExplorerFx {
    ClassTreeView() {
    }
    @Override
    public TreeItem<String>[] TreeCreate(File dir) {//this function is creating trees for every file/directory found in a list of files searched in given directory
        TreeItem<String>[] A = null;
        File[] F1 = dir.listFiles();//stores all the names of files found in dir
        int n = F1.length - FilesHiddensCount(dir);//removing any hidden files present in the directory
        A = new TreeItem[n];//this will create tree for every nonhidden file
        int pos = 0;//
        for (int i = 0; i < F1.length; i++) {
            if (!F1[i].isFile() && !F1[i].isHidden() && F1[i].isDirectory() && n == 0) {//if the current file is not a file and it is not hidden and it is a directory then its tree will be created
                A[pos] = new TreeItem<>(F1[i].getName(), new ImageView(new Image("C:\\Users\\92309\\Documents\\finalproject\\FileExplorer\\src\\main\\java\\com\\example\\fileexplorer\\folder.jpg")));
                pos++;
            } else if (!F1[i].isFile() && !F1[i].isHidden() && F1[i].isDirectory() && n >0) {//a tree will be created at the array A in position pos and then the func is recursively called to attach other dir with it
                A[pos] = new TreeItem<>(F1[i].getName(), new ImageView(new Image("C:\\Users\\92309\\Documents\\finalproject\\FileExplorer\\src\\main\\java\\com\\example\\fileexplorer\\folder.jpg")));
                try {
                    A[pos].getChildren().addAll(TreeCreate(F1[i]));
                    pos++;
                } catch (Exception exception) {
                    System.out.println("Exception x in tree creates at" + F1[i].getAbsolutePath() + " " + exception.getMessage());
                }
            }
        }
        return A;
    }
    @Override
    public String FindAbsolutePath(TreeItem<String> item, String s) {
        if ((item.getParent() == null) || (item.getParent().getValue().equals("This PC "))) {
            return s;
        } else {
            String dir = item.getParent().getValue();
            dir = dir + "\\" + s;
            return FindAbsolutePath((item.getParent()), dir);
        }
    }
    @Override
    public void CreateTreeView(TreeView<String> treeView){
File[] sysroots=File.listRoots();
TreeItem<String> ThisPc=new TreeItem<>("This PC", new ImageView(new Image("C:\\Users\\92309\\Documents\\finalproject\\FileExplorer\\src\\main\\java\\com\\example\\fileexplorer\\pcc.jpg")));
        TreeItem<String>[] drives=new TreeItem[sysroots.length];
        for (int i=0;i<sysroots.length;i++){
            drives[i]= new TreeItem<>(sysroots[i].getAbsolutePath(), new ImageView(new Image("C:\\Users\\92309\\Documents\\finalproject\\FileExplorer\\src\\main\\java\\com\\example\\fileexplorer\\hdd.jpg")));;
        try {
            drives[i].getChildren().addAll(TreeCreate(sysroots[i]));
        }catch (NullPointerException x){
            System.out.println("Exception x detected :"+x.fillInStackTrace()+drives[i].toString());
        }
        finally {
            ThisPc.getChildren().add(drives[i]);
        }
        treeView.setRoot(ThisPc);

            treeView.setCellFactory(param -> new TreeCell<String>() {
                @Override
                protected void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setText(null);
                        setGraphic(null);
                        setStyle(null);
                    } else {
                        setText(item);
                        setGraphic(getTreeItem().getGraphic());

                        // Set background color based on your condition
                        if (item.equals("This PC")) {
                            setStyle("-fx-background-color: #FFDAE9;");
                        } else {
                            setStyle("-fx-background-color: white;");
                        }

                        // Hover effect
                        setOnMouseEntered(event -> {
                            setStyle("-fx-background-color: #FFC0CB; -fx-text-fill:Red"); // Change background color on hover

                        });

                        setOnMouseExited(event -> {
                            if (item.equals("This PC")) {
                                setStyle("-fx-background-color: #FFDAE9;"); // Restore original color on exit for "This PC" item
                            } else {
                                setStyle("-fx-background-color: white;"); // Restore original color on exit for other items
                            }
                        });
                    }
                }
            });



        }
    }
      }