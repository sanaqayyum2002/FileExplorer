package com.example.fileexplorer;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import java.util.List;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.StageStyle;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.function.Predicate;

import static com.example.fileexplorer.ControllerTableView.*;
import static com.example.fileexplorer.ControllerTilesView.Fx3;
import static com.example.fileexplorer.FileExplorerFx.CurrDirStr;

public class Controller implements Initializable {
   @FXML
   private Label label;
   @FXML
   private Button btn;
   private int count;
   @FXML
   private ComboBox actionComboBox;
   static ClassTreeView Fx1;
   static String temp;
    private ObservableList<FileInfo> originalList;

    @FXML
    private Pane secPane;
    @FXML
    private TreeView<String> treeview;
   @FXML
   private void loadFxml(ActionEvent event)throws IOException
   {
       count=(count+1)%2;
       Pane newLoadedPane;
       secPane.getChildren().clear();
       if (count==0){
           newLoadedPane=FXMLLoader.load(getClass().getResource("Scene2.Fxml"));
       }
       else {
           newLoadedPane=FXMLLoader.load(getClass().getResource("Scene3.Fxml"));
       }
       secPane.getChildren().add(newLoadedPane);
       refreshView();
   }
    private void refreshView() {
       //refreshTreeView();
        Fx2.CreateTableView();
        Fx3.CreateTilesView();
    }
    private void refreshTreeView() {
        Fx1.CreateTreeView(treeview);
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
count=0;
Fx1=new ClassTreeView();
Fx1.CurrDirFile=new File("./");
CurrDirStr=Fx1.CurrDirFile.getAbsolutePath();
Fx1.lb1=label;
Fx2.lb1=label;
label.setText(CurrDirStr);
try {
    Pane newLoadedPane= FXMLLoader.load(getClass().getResource("Scene2.fxml"));
    secPane.getChildren().add(newLoadedPane);
}catch (NullPointerException e) {
    e.printStackTrace();
}
catch (IOException e) {
    e.printStackTrace();
}
Fx1.CreateTreeView(treeview);
        actionComboBox.setCellFactory(listView -> new ListCell<String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(item);

                if (item != null) {
                    if (item.equals(actionComboBox.getSelectionModel().getSelectedItem())) {
                        // Change the text color for the selected item
                        setTextFill(Color.WHITE); // Replace with your desired color
                    } else {
                        setTextFill(javafx.scene.paint.Color.BLACK); // Set the default text color
                    }
                }
            }
        });
        actionComboBox.setButtonCell(new ListCell<String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(item);

                if (item != null) {
                    if (item.equals(actionComboBox.getSelectionModel().getSelectedItem())) {
                        // Change the text color for the selected item
                        setTextFill(Color.WHITE); // Replace with your desired color

                    } else {
                        setTextFill(javafx.scene.paint.Color.BLACK); // Set the default text color
                    }
                }
            }
        });
        actionComboBox.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                System.out.println("Selected: " + newValue);
                if(newValue.equals("Rename")) {
                    TableSelectionModel<FileInfo> selectionModel = Fx2.TableView.getSelectionModel();
                    FileInfo selectedItem = selectionModel.getSelectedItem();

                    if (selectedItem != null) {
                        TextInputDialog dialog2 = new TextInputDialog(selectedItem.getName());
                        dialog2.setTitle("Rename File");
                        dialog2.setHeaderText("Enter the new name:");
                        dialog2.setContentText("New Name:");

                        Optional<String> result = createTextInputdialog("Rename File","Enter the new name:","New Name:");
                        result.ifPresent(newName -> {
                            File oldFile = new File(CurrDirStr + File.separator + selectedItem.getName());
                            File newFile = new File(CurrDirStr + File.separator + newName);

                            if (oldFile.renameTo(newFile)) {
                                // Update the TableView
                                selectedItem.setName(newName);
                                Fx2.CreateTableView();
                                showAlert("Success", "File renamed successfully!");
                            } else {
                                showAlert("Error", "Unable to rename the file. Please try again.");
                            }
                        });
                        refreshView();
                        Fx1.CreateTiles();
                    } else {
                        showAlert("Error", "Please select a file to rename.");
                    }

                }
                else if(newValue.equals("Delete")){
                    FileInfo selectedItem = Fx2.TableView.getSelectionModel().getSelectedItem();

                    // Check if an item is selected
                    if (selectedItem != null) {
                        // Get the file associated with the selected item
                        File selectedFile = selectedItem.getFile();

                        // Confirm deletion with a dialog
                        Alert confirmationDialog = new Alert(Alert.AlertType.CONFIRMATION);
                        confirmationDialog.setTitle("Confirmation");
                        confirmationDialog.setHeaderText("Delete File");
                        confirmationDialog.setContentText("Are you sure you want to delete the selected file?");
                        javafx.scene.control.DialogPane dialogPane = confirmationDialog.getDialogPane();

                        // Apply custom styles inline
                        dialogPane.setStyle(
                                "-fx-background-color: #FFDAE9;" +
                                        "-fx-border-color: #DF0F8F; " +
                                        "-fx-border-width: 2px; " +
                                        "-fx-font-size: 14px; " +
                                        "-fx-font-family: 'Arial';"
                        );
                        ButtonBar buttonBar = (ButtonBar) dialogPane.lookup(".button-bar");
                        if (buttonBar != null) {
                            for (Node node : buttonBar.getButtons()) {
                                if (node instanceof Button) {
                                    // Apply custom background color style to each button
                                    node.setStyle("-fx-background-color:DF0F8F;-fx-text-fill:white;");
                                }
                            }
                        }

                        // Show the confirmation dialog
                        confirmationDialog.showAndWait().ifPresent(response -> {
                            if (response == ButtonType.OK) {
                                // User clicked OK, proceed with deletion
                                if (selectedFile.delete()) {
                                    // Remove the item from the tableview
                                    Fx2.TableView.getItems().remove(selectedItem);
                                    showAlert("File deleted successfully.", String.valueOf(Alert.AlertType.INFORMATION));
                                } else {
                                    showAlert("Failed to delete the file.", String.valueOf(Alert.AlertType.ERROR));
                                }
                            }
                        });
                        refreshView();
                    } else {
                        showAlert("No file selected.", String.valueOf(Alert.AlertType.WARNING));
                    }
                }
                else if (newValue.equals("Create New Folder")){

                    Optional<String> result = createTextInputdialog("Create New Folder","Enter the name for the new folder:","Filename:");
                    result.ifPresent(folderName -> {
                        File newFolder = new File(Fx2.CurrDirFile.getAbsolutePath() + File.separator + folderName);

                        if (newFolder.mkdir()) {
                            // Folder creation successful
                            System.out.println("New folder created: " + newFolder.getAbsolutePath());
                            // Refresh the view
                            refreshView();
                        } else {
                            // Folder creation failed
                            System.out.println("Failed to create the new folder.");
                        }
                    });

                }
                else if(newValue.equals("Search")){
                    Optional<String> result = createTextInputdialog("Search Files", "Enter File name to search", "Filename:");
                    result.ifPresent(query -> {
                        originalList = FXCollections.observableArrayList();
                        // Search for files in all directories
                        List<FileInfo> searchResults = searchFilesInAllDirectories(Fx2.CurrDirFile, query);
                        originalList.addAll(searchResults);

                        // Set up the TableView with the search results
                        setTableData(originalList);
                    });
                }
                else if(newValue.equals("Properties")){
                    FileInfo selectedItem = Fx2.TableView.getSelectionModel().getSelectedItem();

                    // Check if an item is selected
                    if (selectedItem != null) {
                        // Get the file associated with the selected item
                        File selectedFile = selectedItem.getFile();
                        showFileProperties(selectedFile);
                    }
                    else {
                        showAlert("No file selected.", String.valueOf(Alert.AlertType.WARNING));
                    }

                }
            }
        });

    }
    @FXML
    private void back(){

    }
    private List<FileInfo> searchFilesInAllDirectories(File directory, String query) {
        List<FileInfo> searchResults = new ArrayList<>();

        if (directory.isDirectory()) {
            // Search files in the current directory
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isFile() && file.getName().toLowerCase().contains(query.toLowerCase())) {
                        // Found a matching file, add it to the search results
                        String name = file.getName();
                        String size = Fx2.calculateSize(file);
                        ImageView icon = new ImageView(Fx2.getIconImageFX(file));

                        searchResults.add(new FileInfo(icon, name, size, file));
                    } else if (file.isDirectory()) {
                        // Recursively search in subdirectories
                        searchResults.addAll(searchFilesInAllDirectories(file, query));
                    }
                }
            }
        }

        return searchResults;
    }


    public Optional<String> createTextInputdialog(String title, String headertext, String contextmenu){
       TextInputDialog dialog=new TextInputDialog("");
       dialog.setTitle(title);
       dialog.setHeaderText(headertext);
       dialog.setContentText(contextmenu);
        dialog.getDialogPane().setStyle(
                "-fx-background-color: #FFDAE9;" +
                        "-fx-border-color: #DF0F8F; " +
                        "-fx-border-width: 2px; " +
                        "-fx-font-size: 14px; " +
                        "-fx-font-family: 'Arial';"
        );
        dialog.getEditor().setStyle("-fx-background-color: #FFDAE9; -fx-text-fill: #DF0F8F;-fx-border-radius:5px; -fx-border-color:#DF0F8F; -fx-border-width:2px;");
        ButtonBar buttonBar = (ButtonBar) dialog.getDialogPane().lookup(".button-bar");
        if (buttonBar != null) {
            for (Node node : buttonBar.getButtons()) {
                if (node instanceof Button) {
                    // Apply custom background color style to each button
                    node.setStyle("-fx-background-color:DF0F8F;-fx-text-fill:white;");
                }
            }
        }
       return dialog.showAndWait();
    }
    private void setTableData(ObservableList<FileInfo> dataList) {
        // Set up the TableView with the provided data
        Fx2.TableView.setItems(dataList);

        //Fx3.CreateTilesView();
    }
    private void filterFiles(String query) {
        if (query == null || query.trim().isEmpty()) {
            // If the search query is empty, display the original list
            setTableData(originalList);
        } else {
            // Filter the files based on the search query
            Predicate<FileInfo> filterCondition = fileInfo ->
                    fileInfo.getName().toLowerCase().contains(query.toLowerCase());
            ObservableList<FileInfo> filteredList = originalList.filtered(filterCondition);
            setTableData(filteredList);
        }
    }
    private ObservableList<FileInfo> getFilesInCurrentDirectory() {
        File[] files = Fx2.CurrDirFile.listFiles();
        if (files != null) {
            return FXCollections.observableArrayList(createFileInfoArray(files));
        } else {
            return FXCollections.observableArrayList();
        }
    }
    private FileInfo[] createFileInfoArray(File[] files) {
        FileInfo[] fileInfoArray = new FileInfo[files.length];
        for (int i = 0; i < files.length; i++) {
            String s1 = files[i].getName();
            String s2 = Fx2.calculateSize(files[i]);

            ImageView img = new ImageView(Fx2.getIconImageFX(files[i]));

            fileInfoArray[i] = new FileInfo(img, s1, s2, files[i]);
        }
        return fileInfoArray;
    }
        public static void showFileProperties(File file) {
            if (file == null || !file.exists()) {
                // File does not exist
                showAlert2("Error", "File not found.");
                return;
            }

            // Create a custom dialog
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("File Properties");
            alert.setHeaderText(null);
            alert.initStyle(StageStyle.UTILITY);
            javafx.scene.control.DialogPane dialogPane = alert.getDialogPane();
            // Apply custom styles inline
            dialogPane.setStyle(
                    "-fx-background-color: #FFDAE9;" +
                            "-fx-border-color: #DF0F8F; " +
                            "-fx-border-width: 2px; " +
                            "-fx-font-size: 14px; " +
                            "-fx-font-family: 'Arial';"
            );
            ButtonBar buttonBar = (ButtonBar) dialogPane.lookup(".button-bar");
            if (buttonBar != null) {
                for (Node node : buttonBar.getButtons()) {
                    if (node instanceof Button) {
                        // Apply custom background color style to each button
                        node.setStyle("-fx-background-color:DF0F8F;-fx-text-fill:white;");
                    }
                }
            }

            // Create a GridPane to display properties
            GridPane grid = new GridPane();
            grid.setHgap(10);
            grid.setVgap(10);

            // Add properties to the GridPane
            grid.addRow(0, new Label("Name:"), new Label(file.getName()));
            grid.addRow(1, new Label("Path:"), new Label(file.getAbsolutePath()));
            grid.addRow(2, new Label("Size:"), new Label(String.valueOf(file.length()) + " bytes"));
            grid.addRow(3, new Label("Type:"), new Label(file.isDirectory() ? "Directory" : "File"));
            grid.addRow(4, new Label("Last Modified:"), new Label(formatDate(file.lastModified())));
            alert.getDialogPane().setContent(grid);

            // Show the dialog
            alert.showAndWait();
        }

        private static String formatDate(long timestamp) {
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
            return sdf.format(timestamp);
        }

        private static void showAlert2(String title, String content) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(title);
            alert.setHeaderText(null);
            alert.setContentText(content);
            javafx.scene.control.DialogPane dialogPane = alert.getDialogPane();
            alert.setContentText(content);
            // Apply custom styles inline
            dialogPane.setStyle(
                    "-fx-background-color: #FFDAE9;" +
                            "-fx-border-color: #DF0F8F; " +
                            "-fx-border-width: 2px; " +
                            "-fx-font-size: 14px; " +
                            "-fx-font-family: 'Arial';"
            );
            ButtonBar buttonBar = (ButtonBar) dialogPane.lookup(".button-bar");
            if (buttonBar != null) {
                for (Node node : buttonBar.getButtons()) {
                    if (node instanceof Button) {
                        // Apply custom background color style to each button
                        node.setStyle("-fx-background-color:DF0F8F;-fx-text-fill:white;");
                    }
                }
            }
            alert.showAndWait();
        }

    @FXML
    private void handleMouseClicked (MouseEvent mouseEvent) {
        String s="";
        if (mouseEvent.getClickCount() == 1) {
            try {
                TreeItem<String> item = treeview.getSelectionModel().getSelectedItem();
                Fx1.CurrDirName =item.getValue();
                System.out.println("Selected text : " + item.getValue());
                System.out.println(item.getParent().getValue());
                String parent="";
                if(item.getValue().equals("This PC")){
                    s="This PC\\";
                }
                else if (item.getValue().equals("C:\\")){
                    s="C:\\";
                }
                else {
                    File[] roots=File.listRoots();

                    while(!(item.getParent().getValue().equals("C:\\"))){
                        parent = item.getParent().getValue() + "\\" + parent;//devices parent Emu
                        item = item.getParent();//First iteration Emu\
                    }
                    s = "C:\\"+parent + Fx1.CurrDirName;
                }
                Fx1.CurrDirFile = new File(s);
                CurrDirStr = s;
                System.out.println("The value of s is"+s);
                label.setText(CurrDirStr);
                Fx2.TableView.getItems().clear();
refreshView();
            } catch (Exception x) {
                System.out.println(x.getMessage());
            }
        }
    }
    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        javafx.scene.control.DialogPane dialogPane = alert.getDialogPane();
        alert.setContentText(content);
        // Apply custom styles inline
        dialogPane.setStyle(
                "-fx-background-color: #FFDAE9;" +
                        "-fx-border-color: #DF0F8F; " +
                        "-fx-border-width: 2px; " +
                        "-fx-font-size: 14px; " +
                        "-fx-font-family: 'Arial';"
        );
        ButtonBar buttonBar = (ButtonBar) dialogPane.lookup(".button-bar");
        if (buttonBar != null) {
            for (Node node : buttonBar.getButtons()) {
                if (node instanceof Button) {
                    // Apply custom background color style to each button
                    node.setStyle("-fx-background-color:DF0F8F;-fx-text-fill:white;");
                }
            }
        }
        alert.showAndWait();
    }
}