package com.example.fileexplorer;

import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ClassTableView extends FileExplorerFx{
    @FXML
    ScrollPane scrollPane;
    public ClassTableView() {
    }
    @Override
    public void setValues(TableView<FileInfo> tableview, TableColumn<FileInfo, ImageView> image, TableColumn<FileInfo, String> name, TableColumn<FileInfo, String> size) {
    this.TableView=tableview;
    this.name=name;
    this.size=size;
    this.image=image;
    }
    @Override
    public void CreateTableView() {
        File[] f1;
        ObservableList<FileInfo> list;
        if (CurrDirFile == null) {
            CurrDirFile = new File("./");
        }
        if (CurrDirName.equals("This PC")) {
            f1 = File.listRoots();
        } else {
            f1 = CurrDirFile.listFiles();
        }
        if (f1 != null) {
            FileInfo st[] = new FileInfo[f1.length];
            for (int i = 0; i < f1.length; i++) {
                String s1 = null;
                String s2 = null;
                ImageView img = null;
                try {
                    if (IsDrive(f1[i])) {
                        img = new ImageView(getIconImageFX(f1[i]));
                        s1 = f1[i].getAbsolutePath();
                    } else {
                        img = new ImageView(getIconImageFX(f1[i]));
                        s1 = f1[i].getName();
                        s2 = calculateSize(f1[i]);
                    }
                } catch (Exception x) {
                    System.out.println("Exception in table view string: " + x.getMessage());
                }
                st[i] = new FileInfo(img, s1, s2, f1[i]);
            }
            list = FXCollections.observableArrayList(st);
            image.setCellValueFactory(new PropertyValueFactory<>("image"));
            name.setCellValueFactory(new PropertyValueFactory<>("name"));
            size.setCellValueFactory(new PropertyValueFactory<>("size"));
            TableView.setItems(list);
        }
    }
}
