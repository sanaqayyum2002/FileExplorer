module com.example.fileexplorer {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens com.example.fileexplorer to javafx.fxml;
    exports com.example.fileexplorer;
}